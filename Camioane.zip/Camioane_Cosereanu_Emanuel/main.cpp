#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <mutex>
#include <pthread.h>
#include <semaphore.h>

#define MAX_MSG 100 //definim numarul maxim de mesaje pe care le putem memora in coada

sem_t sem_pod; //ne declaram semaforul podului (va fi initializat cu 2, pentru ca are doar doua benzi)
int is_done = 0, dist_garaj_oras = 5, dist_oras_semaf = 4, dist_pod = 3, dist_rampa_garaj = 7;
/* Ne declaram variabila is_done (care tine thread urile "in viata", va deveni 1 atunci cand toate camioanele si au terminat turele
 * dist_garaj_ora - distanta este aceeasi pentru fiecare camion
 * dist_oras_semaf - am presupus ca semafoarele se afla in acelasi loc, astfel incat distanta de la oras la ele e aceeasi
 * dist_pod - lungimea podului
 * dist_rampa_garaj - am presupus faptul ca rampele sunt una langa alta si au aceeasi distanta pana la garaj
 * am presupus si ca service ul e fix langa garaj asa ca nu am declarat alta variabila pentru distanta de la service la garaj
 * am presupus ca semafoarele si rampele sunt fix langa pod, primele la intrare, celelalte la iesire de pe pod
 */
int toate_camioanele_in_garaj = 0; //variabila in care vom verifica daca toate camioanele sunt in garaj (dupa ce si au terminat traseele)
time_t prg_start = 0; //pentru a memora timpul de rulare a programului
int N; //numarul de camioane, va fi introdus de la tastatura

//stari camioane
enum {
    ST_CAM_IN_GARAJ, //in garaj
    ST_CAM_OUT_GARAJ, //plecat din garaj
    ST_CAM_IN_SERVICE, //la reparat in service
    ST_CAM_IN_ORAS, //in oras la colectat
    ST_CAM_OUT_ORAS, //iesit din oras
    ST_CAM_SEMAF1, //ajuns la semafor1 pod
    ST_CAM_SEMAF2, //ajuns la semafor2 pod
    ST_CAM_SEMAF3, //ajuns la semafor3 pod
    ST_CAM_POD, //ajuns pe pod
    ST_CAM_RAMPA1, //ajuns la rampa1
    ST_CAM_RAMPA2, //ajuns la rampa2
    ST_CAM_TO_GARAJ, //in drum spre garaj
    ST_CAM_STOP //folosita pentru a opri camionul dupa ce acesta si-a terminat toate turele
};

//initializare camion
typedef struct {
    char nume[20];
    char ora_start[6]; //ex. 08:00 - ora de iesire din garaj
    int ora_max_delay; //ex. 4 - poate intirzia iesirea din garaj cu max 4 minute (random 0..4 min)
    int vit_spre_oras; //ex. 30 km/h - viteza medie spre oras...
    int vit_spre_oras_var; //ex.  5 km/h   ...cu variatie de +/-5 km/h (random -5 ... +5 km/h)
    int vit_in_oras; //ex. 10 km/h - viteza medie in oras...
    int vit_in_oras_var; //ex.  3 km/h   ...cu variatie de +/-3 km/h (random -3 ... +3 km/h)
    int vit_spre_semaf; //viteza pe care camionul o are spre pe pod
    int vit_spre_semaf_var; //variatia vitezei pe camionul o are spre pod
    int vit_pe_pod; //viteza pe pod
    int vit_pe_pod_var; //variatia vitezei pe pod
    int vit_spre_garaj; //viteza de la rampa la garaj
    int vit_spre_garaj_var; //variatiza vitezei de la rampa la garaj
    int dist_in_oras; //distanta in oras pe care trebuie sa o parcurga fiecare camion
    int prima_plecare = 1; //variabila in care memoram daca camionul a mai plecat sau nu din garaj
    int state; //variabila in care memoram starea fiecarul camion
    int tone_gunoi = 0; //variabila folosita pentru a memora tonele de gunoi colectate intr o iesire
    int in_reparatie = 0; //0 - liber sa se duca in garaj, 1 - in reparatie
    int ture; //numarul de ture pe care camionul il va face in ziua respectiva (random intre 1 si 3)
    int reparat = 0; //daca camionul a fost reparat sau nu (cand e in service va avea valoarea 0)
    int semafor_tinta = 0; //variabila in care memoram semaforul la care trebuie sa se duca camionul
    int este_pe_pod = 0; //variabila pe care o folosim pentru a memora daca camionul este pe pod sau nu
    pthread_mutex_t mtx_state; //declaram un mutex pentru starea fiecarui camion
    pthread_mutex_t mtx_reparat; //mutex pentru a l folosi atunci cand modificam variabila reparat
    int ora_min_out_garaj = 0; //memoram timpul plecari de la garaj
    char ora_str_out_garaj[6];
    int ora_min_in_oras = 0; //memoram cand a ajuns in oras
    char ora_str_in_oras[6];
    int ora_min_out_oras; //memoram cand a plecat din oras
    char ora_str_out_oras[6];
    int ora_min_in_semaf; //ora cand a ajuns la semafor
    char ora_str_in_semaf[6];
    int ora_min_in_pod; //ora cand intra pe pod
    char ora_str_in_pod[6];
    int ora_min_out_pod; //ora cand iese de pe pod
    char ora_str_out_pod[6];
    int ora_min_in_rampa; //ora cand intra la rampa
    char ora_str_in_rampa[6];
    int ora_min_in_garaj = 0; //cand intra in garaj
    char ora_str_in_garaj[6];
    //pentru initializarea valorilor se va folosi func_rand pentru diversificare
} init_cam;

//structura mesajelor primite de supervizor
typedef struct {
    char sursa[20]; //cine trimite mesajul (Camion 1...5...9, Garaj, Service, etc)
    char text[100]; //mesajul trimis
} mesaj_t;

typedef struct {
    int total_tone; //pentru a memora numarul total de tone colectat la rampa
    pthread_mutex_t mtx_rampa; //folosim mutex pentru ca un singur camion sa poata accesa rampa
    sem_t sem_rampa; //doar un singur camion poate descarca asa ca vom folosi un semafor
} rampa_t;


mesaj_t coada_mesaje[MAX_MSG]; //ne declaram coada pentru mesaje
int head = 0, tail = 0; //capul, coada coadei :))

pthread_mutex_t mutex_msg; //ne declaram un mutex pentru mesaje
pthread_cond_t cond_msg; //ne declaram o conditie pentru mesaje

void *func_thrd_cam(void *ptr); //functia pentru thread urile camioanelor
void *func_thrd_supervizor(void *p); //functia pentru thread ul supervizor
void *func_thrd_garaj(void *arg); //functia pentru thread ul garaj
void *func_thrd_reparare(void *arg); //functia pentru thread ul reparare (service)
void *func_thrd_rampa1(void *arg); //functia pentru thread ul rampa1
void *func_thrd_rampa2(void *arg); //functia pentru thread ul supervizor rampa2
int func_rand(int min, int max);
rampa_t rampa1, rampa2; //ne declaram 2 structuri de tip rampa

int main() {

    //citim numarul de camioane de la tastatura
    printf("Introdu numarul de camioane (N < 10)\n");
    scanf("%d", &N);
    if (N > 10) {
        printf("Valorea nu este mai mica de 10!!!");
        return 0;
    }

    sem_init(&sem_pod, 0, 2); //initializam semaforul podului cu doua benzi
    sem_init(&rampa1.sem_rampa, 0, 1); //initializam semaforul pentru rampa 1
    sem_init(&rampa2.sem_rampa, 0, 1); //initializam semaforul pentru rampa 2

    pthread_mutex_init(&mutex_msg, NULL); //initializam mutex ul pentru mesaje
    pthread_cond_init(&cond_msg, NULL); //initializam variabila de conditie pentru mesaje
    pthread_mutex_init(&rampa1.mtx_rampa, NULL); //initializam mutex ul pentru rampa 1
    pthread_mutex_init(&rampa2.mtx_rampa, NULL); //initializam mutex ul pentru rampa 2

    pthread_t thrd_cam[N]; //thread-urile pentru camioane
    pthread_t th_supervizor; //declaram thread-ul supervizor
    pthread_t th_reparare; //declaram thread-ul reparare
    pthread_t th_rampa1; //declaram thread-ul rampa1
    pthread_t th_rampa2; //declaram thread-ul rampa2
    pthread_t th_garaj; //declaram thread-ul garaj

    init_cam camioane[N]; //ne declaram 10 camioane
    int ret_cam[N], err; //pentru a memora codul returnat de pthread_create (pentru threadurile camionelor si celelalte)

    //initializare generator numere random
    srandom(time(0));
    //initializare ora pornire program (ca nr. secunde unix)
    prg_start = time(0);

    //configurarea camioanelor
    for (int i = 0; i < N; i++)
    {
        sprintf(camioane[i].nume, "Camion %d", i + 1);
        sprintf(camioane[i].ora_start, "08:0%d", i);
        camioane[i].ora_max_delay = func_rand(0, 4); //intarziere de 0...4 minute
        camioane[i].vit_spre_oras = func_rand(20, 60); //viteza medie intre 20...60 km/h
        camioane[i].vit_spre_oras_var = func_rand(0, 5); //variatia vitezei medii (0...5 km/h) dar va va fii intre -5...+5
        camioane[i].vit_in_oras = func_rand(20, 45); //viteza medie in ora 20...45 km/h
        camioane[i].vit_in_oras_var = func_rand(0, 3); //variatiza vitezei in oras (0..3 km/h) -3...+3
        camioane[i].vit_spre_semaf = func_rand(20, 60); //viteza spre semafor 20..60 km/h
        camioane[i].vit_spre_semaf_var = func_rand(0, 5); //variatia vitezei spre semafor
        camioane[i].vit_pe_pod = func_rand(10, 20); //viteza pe pod 10...20 km/h
        camioane[i].vit_pe_pod_var = func_rand(0, 3); //variatia vitezei pe pod (0...3 km/h) -3...+3
        camioane[i].vit_spre_garaj = func_rand(20, 60); //viteza de la rampa spre garaj 20...60 km/h
        camioane[i].vit_spre_garaj_var = func_rand(0, 5); //variatia vitezei de la rampa la garaj
        camioane[i].dist_in_oras = func_rand(5, 15); //distanta pe care trebuie sa o parcurga cam 1 in oras (5...15 km)
        pthread_mutex_init(&camioane[i].mtx_state, NULL); //initializam mutex ul pentru stare
        pthread_mutex_init(&camioane[i].mtx_reparat, NULL); //initializam mutex ul pentru reparare
        camioane[i].ture = func_rand(1, 3); //random intre 1 si 3 ture
    }

    printf("-------------------------------\n");
    printf("Starting threads...\n");
    //pornim toate camioanele si restul thread urilor
    for (int i = 0; i < N; i++)
        ret_cam[i] = pthread_create(&thrd_cam[i], NULL, func_thrd_cam, (void *)&camioane[i]);

    for (int i = 0; i < N; i++)
        if (ret_cam[i])
        {
            fprintf(stderr,"Error - pthread_create() return code: %d\n", ret_cam[i]);
            exit(EXIT_FAILURE);
        }
    printf("-------------------------------\n");
    for (int i = 0; i < N; i++)
        printf("pthread_create() for thread cam %d returns: %d\n", i, ret_cam[i]);

    err = pthread_create(&th_garaj, NULL, func_thrd_garaj, camioane); //pornim thread-ul garaj
    if (err) {
        fprintf(stderr,"Error - pthread_create() return code: %d\n", err);
        exit(EXIT_FAILURE);
    }
    printf("pthread_create() for thread garaj returns: %d\n", err);
    err = pthread_create(&th_supervizor, NULL, func_thrd_supervizor, NULL); //pornim thread-ul supervizor
    if (err) {
        fprintf(stderr,"Error - pthread_create() return code: %d\n", err);
        exit(EXIT_FAILURE);
    }
    printf("pthread_create() for thread supervizor returns: %d\n", err);
    err = pthread_create(&th_rampa1, NULL, func_thrd_rampa1, camioane); //pornim thread-ul rampa 1
    if (err) {
        fprintf(stderr,"Error - pthread_create() return code: %d\n", err);
        exit(EXIT_FAILURE);
    }
    printf("pthread_create() for thread rampa 1 returns: %d\n", err);
    err = pthread_create(&th_rampa2, NULL, func_thrd_rampa2, camioane); //pornim thread-ul rampa 2
    if (err) {
        fprintf(stderr,"Error - pthread_create() return code: %d\n", err);
        exit(EXIT_FAILURE);
    }
    printf("pthread_create() for thread rampa 2 returns: %d\n", err);
    err = pthread_create(&th_reparare, NULL, func_thrd_reparare, camioane); //pornim thread-ul reparare
    if (err) {
        fprintf(stderr,"Error - pthread_create() return code: %d\n", err);
        exit(EXIT_FAILURE);
    }
    printf("pthread_create() for thread reparare returns: %d\n", err);

    printf("-------------------------------\n");

    //bucla se repetata atata timp cat camioanele nu si au terminat toate turele
    while (!is_done) {
        if (toate_camioanele_in_garaj == N)
            is_done = 1;
    }
    sleep(1);

    //asteptam finalizarea thread urilor
    printf("-------------------------------\n");
    for (int i = 0; i < N; i++)
    {
        printf("pthread_join() for thread cam %d ...\n", i);
        pthread_join(thrd_cam[i], NULL);
    }
    printf("pthread_join() for thread garaj ...\n");
    pthread_join(th_garaj, NULL);

    printf("pthread_join() for thread rampa1 ...\n");
    pthread_join(th_rampa1, NULL);

    printf("pthread_join() for thread rampa2 ...\n");
    pthread_join(th_rampa2, NULL);

    printf("pthread_join() for thread reparare ...\n");
    pthread_join(th_reparare, NULL);

    printf("pthread_join() for thread supervizor ...\n");
    pthread_join(th_supervizor, NULL);
    printf("-------------------------------\n");

    //eliberare resurse semafoare
    sem_destroy(&sem_pod);
    sem_destroy(&rampa1.sem_rampa);
    sem_destroy(&rampa2.sem_rampa);

    //eliberare resurse mutex uri
    for (int i = 0; i < N; i++)
        pthread_mutex_destroy(&camioane[i].mtx_state);
    pthread_mutex_destroy(&rampa1.mtx_rampa);
    pthread_mutex_destroy(&rampa2.mtx_rampa);
    pthread_mutex_destroy(&mutex_msg);

    return 0;
}

//functie care intoarce un numar random cu valoare intre min si max
int func_rand(int min, int max) {
    unsigned long r;
    int rnd;
    r = random();
    r = (max - min + 1) * r / RAND_MAX;
    r = r + min;
    rnd = r;
    return rnd;
}

//functie care intoarce "ora" curenta in minute si string ora:min
int func_ora(char *ora) {
    time_t prg_now = time(0);
    //cite secunde au trecut de la pornire program
    //1 sec program => 1 minut camion
    //adaugam ofset pornire program la ora 7:55 = 7*60+55 = 475
    int min_now = prg_now - prg_start + 475;
    sprintf(ora, "%02d:%02d", (int) trunc(min_now / 60), min_now % 60);
    return min_now;
}

//functie care adauga mesajul trimis in coada
void trimite_mesaj(const char *sursa, const char *text) {
    pthread_mutex_lock(&mutex_msg); //blocam zona critica
    strcpy(coada_mesaje[tail].sursa, sursa); //copiem in coada numele celui care trimite mesajul
    strcpy(coada_mesaje[tail].text, text); //copiem mesajul
    tail = (tail + 1) % MAX_MSG; //marim cu 1/resetam marimea (daca a trecut de 100) indexului coada
    pthread_cond_signal(&cond_msg);
    pthread_mutex_unlock(&mutex_msg); //deblocam zona
}

//thread-ul supervizor
void *func_thrd_supervizor(void *arg) {
    while (!is_done) {
        //bucla continua
        pthread_mutex_lock(&mutex_msg); //blocheaza mutexul pentru ca doar un thread sa poata accesa zona critica (accesul la coada)
        while (head == tail) //verifica daca coada e goala
        {
            pthread_cond_wait(&cond_msg, &mutex_msg); //daca e goala, trimitem un semnal
        }
        mesaj_t m = coada_mesaje[head]; //daca coada nu e goala preia mesajul
        head = (head + 1) % MAX_MSG; //marim cu 1/resetam marimea (daca a trecut de 100) indexului capului
        pthread_mutex_unlock(&mutex_msg); //eliberam mutexul
        printf("[SUPERVIZOR] %s: %s\n", m.sursa, m.text); //afiseaza mesajul
    }
    return NULL;
}

void *func_thrd_cam(void *ptr) {
    init_cam *cam;
    cam = (init_cam *) ptr; //preluam vectorul

    pthread_mutex_lock(&cam->mtx_state);
    cam->state = ST_CAM_IN_GARAJ; //starea initiala
    pthread_mutex_unlock(&cam->mtx_state);
    char ora_str[6];
    int prima_plecare = 1; //variabila folosita pentru a verifica daca camionul pleaca pentru prima data
    //in cazul in care acesta nu pleaca pentru prima data, inainte de plecare se va verifica daca are nevoie de service

    sleep(1);
    trimite_mesaj(cam->nume, "-- start thrd_cam");

    int ora_delay = func_rand(0, cam->ora_max_delay);
    char buff[128]; //buffer temporar pentru mesaj
    sprintf(buff, " * plecare ora %s+%dmins [max %dmins]", cam->ora_start, ora_delay, cam->ora_max_delay); //pentru formatare text
    trimite_mesaj(cam->nume, buff);

    int ora_start_h, ora_start_m;
    sscanf(cam->ora_start, "%d:%d", &ora_start_h, &ora_start_m);
    ora_start_m += ora_delay;
    if (ora_start_m > 60) {
        ora_start_h += (int) trunc(ora_start_m / 60);
        ora_start_m = ora_start_m % 60;
    }
    char ora_start_s[6];
    sprintf(ora_start_s, "%02d:%02d", ora_start_h, ora_start_m);

    sprintf(buff, " + plecare ora %02d:%02d = %s", ora_start_h, ora_start_m, ora_start_s);
    trimite_mesaj(cam->nume, buff);

    //viteza spre oras
    int vit_spre_oras = func_rand(-cam->vit_spre_oras_var, cam->vit_spre_oras_var);
    sprintf(buff, " * viteza spre oras %dkm/h+%dkm/h [var +/-%dkm/h]", cam->vit_spre_oras, vit_spre_oras, cam->vit_spre_oras_var);
    trimite_mesaj(cam->nume, buff);

    vit_spre_oras += cam->vit_spre_oras;
    sprintf(buff, " + viteza spre oras %dkm/h", vit_spre_oras);
    trimite_mesaj(cam->nume, buff);

    //viteza in oras
    int vit_in_oras = func_rand(-cam->vit_in_oras_var, cam->vit_in_oras_var);
    sprintf(buff, " * viteza in oras %dkm/h+%dkm/h [var +/-%dkm/h]", cam->vit_in_oras, vit_in_oras, cam->vit_in_oras_var);
    trimite_mesaj(cam->nume, buff);

    vit_in_oras += cam->vit_in_oras;
    sprintf(buff, " + viteza in oras %dkm/h", vit_in_oras);
    trimite_mesaj(cam->nume, buff);

    //viteza spre pod
    int vit_spre_semaf = func_rand(-cam->vit_spre_semaf_var, cam->vit_spre_semaf_var);
    sprintf(buff, " * viteza spre semafor %dkm/h+%dkm/h [var +/-%dkm/h]", cam->vit_spre_semaf, vit_spre_semaf, cam->vit_spre_semaf_var);
    trimite_mesaj(cam->nume, buff);

    vit_spre_semaf += cam->vit_spre_semaf;
    sprintf(buff, " + viteza spre semafor %dkm/h", vit_spre_semaf);
    trimite_mesaj(cam->nume, buff);

    //viteza pe pod
    int vit_pe_pod = func_rand(-cam->vit_pe_pod_var, cam->vit_pe_pod_var);
    sprintf(buff, " * viteza pe pod %dkm/h+%dkm/h [var +/-%dkm/h]", cam->vit_pe_pod, vit_pe_pod, cam->vit_pe_pod_var);
    trimite_mesaj(cam->nume, buff);

    vit_pe_pod += cam->vit_pe_pod;
    sprintf(buff, " + viteza pe pod %dkm/h", vit_pe_pod);
    trimite_mesaj(cam->nume, buff);

    //viteza spre garaj
    int vit_spre_garaj = func_rand(-cam->vit_spre_garaj_var, cam->vit_spre_garaj_var);
    sprintf(buff, " * viteza spre garaj %dkm/h+%dkm/h [var +/-%dkm/h]", cam->vit_spre_garaj, vit_spre_garaj, cam->vit_spre_garaj_var);
    trimite_mesaj(cam->nume, buff);

    vit_spre_garaj += cam->vit_spre_garaj;
    sprintf(buff, " + viteza spre garaj %dkm/h", vit_spre_garaj);
    trimite_mesaj(cam->nume, buff);

    //numarul de ture pe care il are de facut camionul
    sprintf(buff, " + numarul de ture: %d", cam->ture);
    trimite_mesaj(cam->nume, buff);

    sprintf(buff, "-- running thrd_cam %s", cam->nume);
    trimite_mesaj(cam->nume, buff);

    int ora_min = func_ora(ora_str);

    sprintf(buff, " @%s ora curenta\n", ora_str);
    trimite_mesaj(cam->nume, buff);

    int is_thrd_done = 0;
    while (!is_thrd_done) {
        switch (cam->state) {
            case ST_CAM_IN_GARAJ: {
                sleep(1);
                break;
            }
            case ST_CAM_OUT_GARAJ:
            {
                //asteptam sa parcurga traseul garaj->oras
                ora_min = func_ora(ora_str); //obtinem ora curenta

                //verificam daca a ajuns in oras
                if (ora_min >= cam->ora_min_in_oras) {

                    //modificare stare
                    pthread_mutex_lock(&cam->mtx_state);
                    cam->state = ST_CAM_IN_ORAS;
                    pthread_mutex_unlock(&cam->mtx_state);

                    //retinem ora sosirii in oras
                    cam->ora_min_in_oras = ora_min;
                    sprintf(cam->ora_str_in_oras, ora_str);

                    //calculam cand trebuie sa iasa din oras
                    float min_in_oras = 60.0 * cam->dist_in_oras / cam->vit_in_oras;
                    cam->ora_min_out_oras = ora_min + trunc(min_in_oras);

                    //notificare supervizor cu ora la care a ajuns in oras camionul
                    sprintf(buff, "@%s ajuns in oras %s -> ST_CAM_IN_ORAS", ora_str, cam->nume);
                    trimite_mesaj(cam->nume, buff);

                    //notificare supervizor cu ora la care trebuie sa iasa din oras
                    sprintf(buff, "va iesi din oras la @%02d:%02d (estimare)", (int) trunc(cam->ora_min_out_oras / 60), cam->ora_min_out_oras % 60);
                    trimite_mesaj(cam->nume, buff);
                }
                sleep(1);
                break;
            }
            case ST_CAM_IN_ORAS: {
                char ora_str[6];
                ora_min = func_ora(ora_str); //obtinem ora curenta

                //verificam daca a venit momentul sa iasa din oras
                if (ora_min >= cam->ora_min_out_oras) {
                    //simulam cantitatea de gunoi colectata
                    cam ->tone_gunoi = func_rand(5, 20); //intre 5 si 20 de tone

                    //retinem ora iesirii din oras
                    cam->ora_min_out_oras = ora_min;
                    sprintf(cam->ora_str_out_oras, "%s", ora_str);

                    //notificare supervizor cu numarul de tone de gunoi colectate
                    sprintf(buff,"@%s %s a colectat %d tone de gunoi (intrare @%s, plecare @%s) -> ST_CAM_OUT_ORAS", ora_str, cam->nume,cam->tone_gunoi,cam->ora_str_in_oras,cam->ora_str_out_oras);
                    trimite_mesaj(cam->nume, buff);

                    //schimbam starea
                    pthread_mutex_lock(&cam->mtx_state);
                    cam->state = ST_CAM_OUT_ORAS;
                    pthread_mutex_unlock(&cam->mtx_state);
                }
                sleep(1);
                break;
            }
            case ST_CAM_OUT_ORAS: {
                char ora_str[6];
                ora_min = func_ora(ora_str);

                //daca nu am ales inca semaforul
                if (cam->semafor_tinta == 0)
                {
                    cam->semafor_tinta = func_rand(1, 3); //alegem random semaforul spre care se va indrepta camionul

                    //notificam supervizorul referizor la semaforul catre care se indreapta camionul
                    sprintf(buff, "Se indreapta spre semafor %d -> ST_CAM_SEMAF%d", cam->semafor_tinta, cam->semafor_tinta);
                    trimite_mesaj(cam->nume, buff);

                    //calculam timpul estimat (distanta de la oras la semafoare este aceeasi pe oricare drum ar lua o camionul)
                    float min_spre_semaf = 60.0 * dist_oras_semaf / cam->vit_spre_semaf;
                    cam->ora_min_in_semaf = ora_min + trunc(min_spre_semaf);

                    //Notificam supervizorul referitor la timpul la care va trebui sa ajunga camionul la semafor
                    sprintf(buff, "Va ajunge la semafor %d la @%02d:%02d (estimare)", cam->semafor_tinta, cam->ora_min_in_semaf / 60, cam->ora_min_in_semaf % 60);
                    trimite_mesaj(cam->nume, buff);

                    /*IMPORTANT
                     *se va pierde de fiecare data 1 minut de la momentul in care se estimeaza ca va ajunge camionul la semafor
                     *pana la momentul in care acesta ajunge real la semafor
                     *banuiesc ca din cauza sleep ului
                     *asa ca am folosit usleep pentru a verifica la fiecare 0.2 secunde si a mai elimina din "erori"
                     */
                }

                //verificam daca a ajuns la semafor
                if (ora_min >= cam->ora_min_in_semaf)
                {
                    //schimbam starea in functie de semaforul la care trebuia sa ajunga camionul
                    pthread_mutex_lock(&cam->mtx_state);
                    cam->state = ST_CAM_SEMAF1 + (cam->semafor_tinta - 1);
                    pthread_mutex_unlock(&cam->mtx_state);
                }
                usleep(200000); //0.2 secunde
                break;
            }
            case ST_CAM_SEMAF1:
            case ST_CAM_SEMAF2:
            case ST_CAM_SEMAF3:
            {
                //obtinem ora curenta
                ora_min = func_ora(ora_str);
                int sem = cam->state - ST_CAM_SEMAF1 + 1;  //semaforul 1, 2 sau 3

                //salvam ora sosirii
                cam->ora_min_in_semaf = ora_min;
                sprintf(cam->ora_str_in_semaf, "%s", ora_str);

                //mesaj catre supervizor referitor la faptul ca trebuie sa intre pe pod
                sprintf(buff, "@%s a ajuns la semafor %d si se pregateste sa intre pe pod -> ST_CAM_POD", ora_str, sem);
                trimite_mesaj(cam->nume, buff);

                //schimbam starea
                pthread_mutex_lock(&cam->mtx_state);
                cam->state = ST_CAM_POD;
                pthread_mutex_unlock(&cam->mtx_state);

                //resetam semaforul tinta pentru a l putea alege din nou
                cam->semafor_tinta = 0;
                sleep(1);
                break;
            }
            case ST_CAM_POD:
            {
                char ora_str[6];
                ora_min = func_ora(ora_str); //obtinem ora curenta

                //daca nu a intrat inca pe pod
                if (!cam->este_pe_pod)
                {
                    sem_wait(&sem_pod); //intra pe pod
                    cam->este_pe_pod = 1;

                    //ora intrare pe pod
                    cam->ora_min_in_pod = ora_min;
                    sprintf(cam->ora_str_in_pod, "%s", ora_str);

                    //notificam supervizorul (camionul a intrat pe pod)
                    sprintf(buff, "@%s a intrat pe pod -> ST_CAM_POD", cam->ora_str_in_pod);
                    trimite_mesaj(cam->nume, buff);

                    //calcul estimare iesire
                    float min_in_pod = 60.0 * dist_pod / cam->vit_pe_pod;
                    cam->ora_min_out_pod = ora_min + trunc(min_in_pod);

                    //trimitem mesaj supervizorului cu ora la care va trebui sa iasa camionul de pe pod
                    sprintf(buff, "Va iesi de pe pod la @%02d:%02d (estimare)", cam->ora_min_out_pod / 60, cam->ora_min_out_pod % 60);
                    trimite_mesaj(cam->nume, buff);
                }
                //verificam daca a venit momentul sa iasa
                if (ora_min >= cam->ora_min_out_pod)
                {
                    //ora iesire de pe pod
                    cam->ora_min_out_pod = ora_min;
                    sprintf(cam->ora_str_out_pod, "%s", ora_str);

                    sprintf(buff, "@%s a iesit de pe pod", cam->ora_str_out_pod);
                    trimite_mesaj(cam->nume, buff);

                    sem_post(&sem_pod); //elibereaza podul
                    cam->este_pe_pod = 0; //resetam valoarea, camionul nu mai este pe pod

                    //alegem rampa
                    int rampa = func_rand(1, 2);

                    //trimitem camionul catre rampa aleasa
                    pthread_mutex_lock(&cam->mtx_state);
                    cam->state = (rampa == 1 ? ST_CAM_RAMPA1 : ST_CAM_RAMPA2);
                    pthread_mutex_unlock(&cam->mtx_state);

                    //notificam supervizorul referitor la rampa catre care se indreapta camionul
                    sprintf(buff, "Se indreapta spre rampa %d -> ST_CAM_RAMPA%d", rampa, rampa);
                    trimite_mesaj(cam->nume, buff);
                }

                sleep(1);
                break;
            }
            case ST_CAM_RAMPA1:
            case ST_CAM_RAMPA2:
            {
                ora_min = func_ora(ora_str); //obtinem ora curenata
                sprintf(cam->ora_str_in_rampa, "%s", ora_str);
                cam->ora_min_in_rampa = ora_min;

                int rampa = (cam->state == ST_CAM_RAMPA1 ? 1 : 2); //rampa 1 sau rampa 2

                //notificam supervizorul referitor la faptul ca se asteapta descarcarea gunoiului
                sprintf(buff, "@%s a ajuns la RAMPA %d! Asteapta descarcarea...", cam->ora_str_in_rampa, rampa);
                trimite_mesaj(cam->nume, buff);
                sleep(1);
                break;
            }
            case ST_CAM_TO_GARAJ:
            {
                char ora_str[6];
                ora_min = func_ora(ora_str); //obtinem ora curenta

                //calculam ora estimata de sosire in garaj
                if (cam->ora_min_in_garaj == 0)
                {
                    float min_spre_garaj = 60.0 * dist_rampa_garaj / cam->vit_spre_garaj;
                    cam->ora_min_in_garaj = ora_min + trunc(min_spre_garaj);

                    //notificam supervizorul cu ora la care camionul va trebui sa ajunga l garaj
                    sprintf(buff, "Va ajunge la garaj la @%02d:%02d (estimare)", cam->ora_min_in_garaj / 60, cam->ora_min_in_garaj % 60);
                    trimite_mesaj(cam->nume, buff);
                }

                // verificam daca a ajuns
                if (ora_min >= cam->ora_min_in_garaj)
                {
                    sprintf(cam->ora_str_in_garaj, "%s", ora_str);

                    //notificam supervizorul (camionul a ajuns la garaj)
                    sprintf(buff, "@%s camionul s-a intors la garaj -> ST_CAM_IN_GARAJ", cam->ora_str_in_garaj);
                    trimite_mesaj(cam->nume, buff);

                    //schimbam starea (camionul este in garaj)
                    pthread_mutex_lock(&cam->mtx_state);
                    cam->state = ST_CAM_IN_GARAJ;
                    pthread_mutex_unlock(&cam->mtx_state);

                    // resetam pentru data viitoare
                    cam->ora_min_in_garaj = 0;
                }

                sleep(1);
                break;
            }
            case ST_CAM_IN_SERVICE:
            {
                ora_min = func_ora(ora_str); //obtinem ora curenta
                //notifcam supervizorul (camionul este in reparatii)
                sprintf(buff, "@%s camionul a intrat in service. Asteapta reparatia...", ora_str);
                trimite_mesaj(cam->nume, buff);
                sleep(1);
                break;
            }
            case ST_CAM_STOP:
                is_thrd_done = 1; //thread ul s a incheiat
                ora_min = func_ora(ora_str); //obtinem ora curenta
                //notificam supervizorul (camionul si a terminat toate turele)
                sprintf(buff, "@%s camionul si-a terminat turele... -> ST_CAM_STOP", ora_str);
                trimite_mesaj(cam->nume, buff);
                sleep(1);
                break;
        } //switch
    } //while
    return 0;
}

//thread-ul garaj
void *func_thrd_garaj(void *arg)
{
    init_cam *camioane = (init_cam *)arg; //primim vectorul

    char ora_str[6], buff[128];
    int ora_min;

    while (!is_done) {
        ora_min = func_ora(ora_str); //obtinem ora curenta

        for (int i = 0; i < N; i++) {
            init_cam *cam = &camioane[i];

            //daca camionul si a terminat turele si se afla in garaj nu mai e nevoie sa iasa din garaj
            if (cam->ture == 0 && cam->state == ST_CAM_IN_GARAJ) {
                toate_camioanele_in_garaj++; //un camion si a terminat turele asa ca l adaugam in garaj

                //schimbam starea (camionul este oprit)
                pthread_mutex_lock(&cam->mtx_state);
                cam->state = ST_CAM_STOP;
                pthread_mutex_unlock(&cam->mtx_state);
            }

            pthread_mutex_lock(&cam->mtx_state);

            //daca camionul se afla in garaj
            if (cam->state == ST_CAM_IN_GARAJ) {

                //daca se afla la prima plecare din garaj (il trimitem direct in oras, nu verificam daca are nevoie de service)
                //daca camionul a fost reparat il trimitem pe traseu (daca mai are ture de facut)
                if (cam->prima_plecare == 1 || cam->reparat == 1) {
                    if (strcmp(ora_str, cam->ora_start) >= 0) {
                        cam->prima_plecare = 0;
                        cam->state = ST_CAM_OUT_GARAJ;

                        //notificam supervizorul (camionul pleaca din garaj)
                        sprintf(buff, "@%s [GARAJ] %s pleaca din garaj -> ST_CAM_OUT_GARAJ", ora_str, cam->nume); //trimitem mesajul si catre supervizor
                        trimite_mesaj(cam->nume, buff);

                        cam->ture--; //scadem numarul de ture pe care il mai are de facut camionul in oras

                        cam->ora_min_out_garaj = ora_min;
                        sprintf(cam->ora_str_out_garaj, ora_str);

                        //calculam cand trebuie sa ajunga in oras
                        float min_garaj_oras = 60.0 * dist_garaj_oras / cam->vit_spre_oras;
                        cam->ora_min_in_oras = ora_min + trunc(min_garaj_oras);

                        //notificare supervizor (cand trebuie sa ajunga camionul in oras)
                        char buff[128];
                        sprintf(buff, "[GARAJ] Va ajunge in oras la @%02d:%02d (estimare)", (int) trunc(cam->ora_min_in_oras / 60), cam->ora_min_in_oras % 60);
                        trimite_mesaj(cam->nume, buff);

                        pthread_mutex_lock(&cam->mtx_reparat);
                        cam->reparat = 0;   //camionul nu este reparat (are nevoie de verificare cand ajunge din oras in garaj)
                        pthread_mutex_unlock(&cam->mtx_reparat);
                    }
                }
                //plecari uleterioare
                else {
                    int defect = func_rand(0, 1); //alegem random daca e defect sau nu
                    if (defect == 1) {
                        cam->state = ST_CAM_IN_SERVICE; //camionul trebuie trimis in service
                        pthread_mutex_lock(&cam->mtx_reparat);
                        cam->reparat = 0;   //camionul nu este reparat
                        pthread_mutex_unlock(&cam->mtx_reparat);
                        //notificare supervizor (camionul este trimis in service)
                        sprintf(buff, "@%s [GARAJ] %s DEFECT! Trimis in service -> ST_CAM_IN_SERVICE", ora_str, cam->nume);
                        trimite_mesaj(cam->nume, buff);
                    }
                    else {
                        cam->state = ST_CAM_OUT_GARAJ;
                        //notificare supervizorul (camionul nu este defect si pleaca spre oras)
                        sprintf(buff, "@%s [GARAJ] %s pleaca din garaj spre oras -> ST_CAM_OUT_GARAJ", ora_str, cam->nume);
                        trimite_mesaj(cam->nume, buff);

                        pthread_mutex_lock(&cam->mtx_reparat);
                        cam->reparat = 0;   //camionul nu este reparat (are nevoie de verificare cand ajunge din oras)
                        pthread_mutex_unlock(&cam->mtx_reparat);

                        cam->ture --; //scadem numarul de ture pe care il mai are de facut camionul in oras
                    }
                }
            }
            pthread_mutex_unlock(&cam->mtx_state);
        }
        sleep(1);
    }
    return NULL;
}

//thread-ul reparare
void *func_thrd_reparare(void *arg)
{
    init_cam *camioane = (init_cam *)arg; //primim vectorul
    char ora_str[6], buff[128];
    int ora_min;

    while (!is_done)
    {
        ora_min = func_ora(ora_str); //obtinem ora curenta
        for (int i = 0; i < N; i++)
        {
            init_cam *cam = &camioane[i];

            // camionul este in service si nu este deja in lucru
            if (cam->state == ST_CAM_IN_SERVICE && cam->in_reparatie == 0)
            {
                cam->in_reparatie = 1;

                int timp_service = func_rand(3, 6); //alegem un timp random de stat in service

                //notifcam supervizorul (camionul intra in service)
                sprintf(buff, "@%s [SERVICE] %s intra in reparatii (%d min) -> ST_CAM_IN_SERVICE", ora_str, cam->nume, timp_service);
                trimite_mesaj("Service", buff);

                sleep(timp_service); //simulam timpul de reparare

                ora_min = func_ora(ora_str); //obtinem ora curenta pentru a afisa cand s a terminat reparatia
                //nofiticam supervizorul ca s a termiant reparatia camionului
                sprintf(buff, "@%s [SERVICE] %s reparat complet! Pleaca in garaj -> ST_CAM_IN_GARAJ", ora_str, cam->nume);
                trimite_mesaj("Service", buff);
                pthread_mutex_lock(&cam->mtx_reparat);
                cam->reparat = 1; //camionul a fost reparat si poate fi trimis direct pe traseu
                pthread_mutex_unlock(&cam->mtx_reparat);

                // chimbam starea camionului
                pthread_mutex_lock(&cam->mtx_state);
                cam->state = ST_CAM_IN_GARAJ;
                pthread_mutex_unlock(&cam->mtx_state);

                cam->in_reparatie = 0;
            }
        }
        sleep(1);
    }

    return NULL;

}

void *func_thrd_rampa1(void *arg)
{
    init_cam *camioane = (init_cam *)arg; //primim vectorul
    char ora_str[6], buff[128];
    int ora_min;

    while (!is_done)
    {
        ora_min = func_ora(ora_str); //obtinem ora curenta
        for (int i = 0; i < N; i++)
        {
            init_cam *cam = &camioane[i];

            if (cam->state == ST_CAM_RAMPA1)
            {
                sem_wait(&rampa1.sem_rampa);
                pthread_mutex_lock(&rampa1.mtx_rampa);
                //cantarire
                rampa1.total_tone += cam->tone_gunoi;

                //notificare supervizor (cate tone s au descarcat de pe camion, cate tone sunt in total in rampa)
                sprintf(buff, "@%s %s a descarcat %d tone. Rampa are un total de %d tone!", ora_str, cam->nume, cam->tone_gunoi, rampa1.total_tone);
                trimite_mesaj("Rampa 1", buff);
                pthread_mutex_unlock(&rampa1.mtx_rampa);

                ora_min = func_ora(ora_str); //obtinem ora curenta
                //camionul pleaca spre garaj
                pthread_mutex_lock(&cam->mtx_state);
                cam->state = ST_CAM_TO_GARAJ;
                pthread_mutex_unlock(&cam->mtx_state);

                //notificare supervizor (camionul a plecat de la rampa la garaj)
                sprintf(buff, "@%s %s se indreapta spre garaj -> ST_CAM_TO_GARAJ", ora_str, cam->nume);
                trimite_mesaj("Rampa 1", buff);

                sem_post(&rampa1.sem_rampa);
            }
        }
        sleep(1);
    }
    return NULL;
}

void *func_thrd_rampa2(void *arg)
{
    init_cam *camioane = (init_cam *)arg; //primim vectorul
    char ora_str[6], buff[128];
    int ora_min;

    while (!is_done)
    {
        ora_min = func_ora(ora_str); //obtinem ora curenta
        for (int i = 0; i < N; i++)
        {
            init_cam *cam = &camioane[i];

            if (cam->state == ST_CAM_RAMPA2)
            {
                sem_wait(&rampa2.sem_rampa);
                pthread_mutex_lock(&rampa2.mtx_rampa);
                //cantarire
                rampa2.total_tone += cam->tone_gunoi;

                //notificare supervizor (cate tone s au descarcat de pe camion, cate tone sunt in total in rampa)
                sprintf(buff, "@%s %s a descarcat %d tone. Rampa are un total de %d tone!", ora_str, cam->nume, cam->tone_gunoi, rampa2.total_tone);
                trimite_mesaj("Rampa 2", buff);
                pthread_mutex_unlock(&rampa2.mtx_rampa);

                ora_min = func_ora(ora_str); //obtinem ora curenta
                //camionul pleaca spre garaj
                pthread_mutex_lock(&cam->mtx_state);
                cam->state = ST_CAM_TO_GARAJ;
                pthread_mutex_unlock(&cam->mtx_state);

                //notificare supervizor (camionul a plecat de la rampa la garaj)
                sprintf(buff, "@%s %s se indreapta spre garaj -> ST_CAM_TO_GARAJ", ora_str, cam->nume);
                trimite_mesaj("Rampa 2", buff);

                sem_post(&rampa2.sem_rampa);
            }
        }
        sleep(1);
    }
    return NULL;
}